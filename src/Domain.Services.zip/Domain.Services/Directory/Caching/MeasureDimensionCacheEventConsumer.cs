﻿namespace Domain.Services.Directory.Caching;

/// <summary>
/// Represents a measure dimension cache event consumer
/// </summary>
public partial class MeasureDimensionCacheEventConsumer : CacheEventConsumer<MeasureDimension>
{
}